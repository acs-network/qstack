#include "eal_private.h"

uint64_t
get_tsc_freq_arch(void)
{
	return 0;
}
