/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright 2014 6WIND S.A.
 */

#ifndef _RTE_DEVARGS_H_
#define _RTE_DEVARGS_H_

/**
 * @file
 *
 * RTE devargs: list of devices and their user arguments
 *
 * This file stores a list of devices and their arguments given by
 * the user when a DPDK application is started. These devices can be PCI
 * devices or virtual devices. These devices are stored at startup in a
 * list of rte_devargs structures.
 */

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <sys/queue.h>
#include <rte_compat.h>
#include <rte_bus.h>

/**
 * Type of generic device
 */
enum rte_devtype {
	RTE_DEVTYPE_WHITELISTED_PCI,
	RTE_DEVTYPE_BLACKLISTED_PCI,
	RTE_DEVTYPE_VIRTUAL,
};

/**
 * Structure that stores a device given by the user with its arguments
 *
 * A user device is a physical or a virtual device given by the user to
 * the DPDK application at startup through command line arguments.
 *
 * The structure stores the configuration of the device, its PCI
 * identifier if it's a PCI device or the driver name if it's a virtual
 * device.
 */
struct rte_devargs {
	/** Next in list. */
	TAILQ_ENTRY(rte_devargs) next;
	/** Type of device. */
	enum rte_devtype type;
	/** Device policy. */
	enum rte_dev_policy policy;
	/** Bus handle for the device. */
	struct rte_bus *bus;
	/** Name of the device. */
	char name[RTE_DEV_NAME_MAX_LEN];
	/** Arguments string as given by user or "" for no argument. */
	char *args;
};

/** user device double-linked queue type definition */
TAILQ_HEAD(rte_devargs_list, rte_devargs);

/** Global list of user devices */
extern struct rte_devargs_list devargs_list;

/**
 * Parse a devargs string.
 *
 * For PCI devices, the format of arguments string is "PCI_ADDR" or
 * "PCI_ADDR,key=val,key2=val2,...". Examples: "08:00.1", "0000:5:00.0",
 * "04:00.0,arg=val".
 *
 * For virtual devices, the format of arguments string is "DRIVER_NAME*"
 * or "DRIVER_NAME*,key=val,key2=val2,...". Examples: "net_ring",
 * "net_ring0", "net_pmdAnything,arg=0:arg2=1".
 *
 * The function parses the arguments string to get driver name and driver
 * arguments.
 *
 * @param devargs_str
 *   The arguments as given by the user.
 * @param drvname
 *   The pointer to the string to store parsed driver name.
 * @param drvargs
 *   The pointer to the string to store parsed driver arguments.
 *
 * @return
 *   - 0 on success
 *   - A negative value on error
 */
int rte_eal_parse_devargs_str(const char *devargs_str,
				char **drvname, char **drvargs);

/**
 * Parse a device string.
 *
 * Verify that a bus is capable of handling the device passed
 * in argument. Store which bus will handle the device, its name
 * and the eventual device parameters.
 *
 * @param dev
 *   The device declaration string.
 * @param da
 *   The devargs structure holding the device information.
 *
 * @return
 *   - 0 on success.
 *   - Negative errno on error.
 */
int __rte_experimental
rte_eal_devargs_parse(const char *dev,
		      struct rte_devargs *da);

/**
 * Insert an rte_devargs in the global list.
 *
 * @param da
 *  The devargs structure to insert.
 *
 * @return
 *   - 0 on success
 *   - Negative on error.
 */
int __rte_experimental
rte_eal_devargs_insert(struct rte_devargs *da);

/**
 * Add a device to the user device list
 *
 * For PCI devices, the format of arguments string is "PCI_ADDR" or
 * "PCI_ADDR,key=val,key2=val2,...". Examples: "08:00.1", "0000:5:00.0",
 * "04:00.0,arg=val".
 *
 * For virtual devices, the format of arguments string is "DRIVER_NAME*"
 * or "DRIVER_NAME*,key=val,key2=val2,...". Examples: "net_ring",
 * "net_ring0", "net_pmdAnything,arg=0:arg2=1". The validity of the
 * driver name is not checked by this function, it is done when probing
 * the drivers.
 *
 * @param devtype
 *   The type of the device.
 * @param devargs_str
 *   The arguments as given by the user.
 *
 * @return
 *   - 0 on success
 *   - A negative value on error
 */
int rte_eal_devargs_add(enum rte_devtype devtype, const char *devargs_str);

/**
 * Remove a device from the user device list.
 * Its resources are freed.
 * If the devargs cannot be found, nothing happens.
 *
 * @param busname
 *   bus name of the devargs to remove.
 *
 * @param devname
 *   device name of the devargs to remove.
 *
 * @return
 *   0 on success.
 *   <0 on error.
 *   >0 if the devargs was not within the user device list.
 */
int __rte_experimental rte_eal_devargs_remove(const char *busname,
					  const char *devname);

/**
 * Count the number of user devices of a specified type
 *
 * @param devtype
 *   The type of the devices to counted.
 *
 * @return
 *   The number of devices.
 */
unsigned int
rte_eal_devargs_type_count(enum rte_devtype devtype);

/**
 * This function dumps the list of user device and their arguments.
 *
 * @param f
 *   A pointer to a file for output
 */
void rte_eal_devargs_dump(FILE *f);

#ifdef __cplusplus
}
#endif

#endif /* _RTE_DEVARGS_H_ */
